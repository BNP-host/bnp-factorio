data:extend{
    {
        type = 'sprite',
        name = 'inserter-throughput-toggle-button',
        filename = '__inserter-throughput__/graphics/toggle-button.png',
        size = 64,
        flags = {'gui-icon'}
    },
    {
        type = 'custom-input',
        name = 'inserter-throughput-toggle',
        localized_name = 'inserter-throughput-toggle-keybind',
        key_sequence = ""
    }
}

local styles = data.raw['gui-style'].default
local button_style = styles.slot_sized_button

styles.inserter_throughput_pressed_button = {
    type = 'button_style',
    parent = 'slot_sized_button',
    default_graphical_set = button_style.clicked_graphical_set,
    clicked_graphical_set = button_style.default_graphical_set
}
