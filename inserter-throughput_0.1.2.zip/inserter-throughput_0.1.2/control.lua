local calc = require('calc')
local draw_text = rendering.draw_text
local destroy_text = rendering.destroy

local text_color = {1, 1, 1}

-- LOGIC

local function vector(from, to)
    return {to.x - from.x, to.y - from.y}
end

local function get_throughput_info(inserter, precision)
    local inserter_position = inserter.position
    local prototype = (inserter.type == 'entity-ghost'
        and inserter.ghost_prototype or inserter.prototype)
    local stack_size = inserter.inserter_stack_size_override
    if stack_size == 0 then
        local force = inserter.force
        if prototype.stack then
            stack_size = 1 + force.stack_inserter_capacity_bonus
        else
            stack_size = 1 + force.inserter_stack_size_bonus
        end
    end
    
    local pickup_position = inserter.pickup_position
    local pickup_target = inserter.pickup_target
    local pickup_belt_speed = 0
    if not pickup_target then
        pickup_target = inserter.surface.find_entities_filtered{
            position = pickup_position}[1]
    end
    if pickup_target then
        if pickup_target.type == 'entity-ghost' then
            pickup_belt_speed = pickup_target.ghost_prototype.belt_speed or 0
        else
            pickup_belt_speed = pickup_target.prototype.belt_speed or 0
        end
    end
    
    local drop_position = inserter.drop_position
    local drop_target = inserter.drop_target
    local drop_belt_speed = 0
    if not drop_target then
        drop_target = inserter.surface.find_entities_filtered{
            position = drop_position}[1]
    end
    if drop_target then
        if drop_target.type == 'entity-ghost' then
            drop_belt_speed = drop_target.ghost_prototype.belt_speed or 0
        else
            drop_belt_speed = drop_target.prototype.belt_speed or 0
        end
    end
    
    local value = calc(
        prototype.inserter_rotation_speed,
        prototype.inserter_extension_speed,
        vector(inserter_position, pickup_position),
        vector(inserter_position, drop_position),
        stack_size,
        pickup_belt_speed,
        drop_belt_speed
    )
    local value_string = tostring(value)
    if precision > 0 then
        local rounded = string.format(string.format('%%.%if', precision), value)
        if string.len(rounded) < string.len(value_string) then
            value_string = rounded
        end
    end
    return {'', value_string, {'per-second-suffix'}}
end

-- GUI

local function on_entity_selected(event)
    -- event.player_index   current player
    -- event.last_entity    previous entity
    local player_index = event.player_index
    local player_settings = settings.get_player_settings(player_index)
    if not player_settings['inserter-throughput-enabled'].value then
        return
    end
    local current_entity = game.get_player(player_index).selected
    local global_player_data = global.player_data
    local data = global_player_data[player_index]
    local text_id = data and data.text_id
    if current_entity and (current_entity.type == 'inserter'
            or current_entity.type == 'entity-ghost'
            and current_entity.ghost_type == 'inserter') then
        if not data then
            data = {}
            global_player_data[player_index] = data
        elseif data.text_id then
            destroy_text(data.text_id)
        end
        local precision = player_settings['inserter-throughput-rounding-precision'].value
        data.text_id = draw_text{
            text = get_throughput_info(current_entity, precision),
            surface = current_entity.surface,
            target = current_entity,
            target_offset = {1, -1},
            color = text_color,
            players = {player_index},
            scale_with_zoom = true
        }
    elseif text_id then
        destroy_text(text_id)
        data.text_id = nil
    end
end

local function update_toggle_button_state(toggle_button, new_state)
    if new_state then
        toggle_button.style = 'inserter_throughput_pressed_button'
    else
        toggle_button.style = 'slot_sized_button'
    end
end

local function on_setting_changed(event)
    -- event.player_index   player whose setting has changed, if applicable (API seems to be wrong)
    -- event.setting        name of the setting, as seen in the prototype
    -- event.setting_type   type of the setting, as seen in the prototype
    local setting_name = event.setting
    local player_index = event.player_index
    if setting_name == 'inserter-throughput-show-toggle' then
        local button = game.get_player(player_index).gui.top['inserter-throughput-toggle']
        local new_state = settings.get_player_settings(player_index)[setting_name].value
        button.visible = new_state
    elseif setting_name == 'inserter-throughput-enabled' then
        local button = game.get_player(player_index).gui.top['inserter-throughput-toggle']
        local new_state = settings.get_player_settings(player_index)[setting_name].value
        update_toggle_button_state(button, new_state)
        if not new_state then -- remove the tooltip on disable, if any
            local data = global.player_data[player_index]
            local text_id = data and data.text_id
            if text_id then
                destroy_text(text_id)
                data.text_id = nil
            end
        end
    end
end

local function on_toggle(event)
    -- event.player_index   player who triggered the custom input (unlisted in API)
    local player_settings = settings.get_player_settings(event.player_index)
    local enabled_setting = player_settings['inserter-throughput-enabled']
    enabled_setting.value = not enabled_setting.value
    -- this will trigger on_setting_changed above
    player_settings['inserter-throughput-enabled'] = enabled_setting
end

local function on_gui_clicked(event)
    -- event.element        clicked element
    -- event.player_index   player who clicked
    -- event.button         mouse button
    -- event.alt            state of Alt key
    -- event.control        state of Ctrl key
    -- event.shift          state of Shift key
    if event.element.name == 'inserter-throughput-toggle' then
        on_toggle(event)
    end
end

-- INITIALIZATION

local function init_toggle_button(player)
    local top_gui = player.gui.top
    local toggle_element = top_gui['inserter-throughput-toggle']
    if not toggle_element then
        toggle_element = top_gui.add{
            type = 'sprite-button',
            name = 'inserter-throughput-toggle',
            tooltip = {'inserter-throughput.toggle-button-tooltip'},
            sprite = 'inserter-throughput-toggle-button'
        }
    end
    local player_settings = settings.get_player_settings(player)
    toggle_element.visible = player_settings['inserter-throughput-show-toggle'].value
    update_toggle_button_state(toggle_element, player_settings['inserter-throughput-enabled'].value)
end

local function init()
    if not global.player_data then
        global.player_data = {}
    end
    -- player_data[player_index] = table
    --      .text_id        id of the rendered text
    for _, player in pairs(game.players) do
        init_toggle_button(player)
    end
end

local function on_player_joined_game(event)
    -- event.player_index   current player
    init_toggle_button(game.get_player(event.player_index))
end

-- EVENTS

script.on_event(defines.events.on_player_joined_game, on_player_joined_game)
script.on_event(defines.events.on_selected_entity_changed, on_entity_selected)
script.on_event(defines.events.on_runtime_mod_setting_changed, on_setting_changed)
script.on_event(defines.events.on_gui_click, on_gui_clicked)
script.on_event('inserter-throughput-toggle', on_toggle)
script.on_init(init)
