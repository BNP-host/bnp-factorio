-- data-updates

require("prototypes.third-party.alien-biomes")
require("prototypes.third-party.aai-industry")
