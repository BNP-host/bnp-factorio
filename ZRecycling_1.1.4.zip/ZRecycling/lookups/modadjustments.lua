--[[
	PLACEHOLDER: HAve not found any use for this yet
	Adjustments to recipes that mods have moved out of vanilla recipe subgroups
	They have become recyclable, and I want to stop that.
]]--

require("constants")
local rec_prefix = constant_rec_prefix


-- Model
if mods["model"] ~= nil then
	-- Think I can just nil the reverse recipes
end

