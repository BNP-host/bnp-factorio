-- The intention is to use these constants in data and control files so that they get changed--
-- in only one place
-- Except it cannot be used in control.lua

-- The prefix used on the reverse recipes
-- Personalised with mod author to avoid clashes with other mods
constant_rec_prefix = "dry411srev-"