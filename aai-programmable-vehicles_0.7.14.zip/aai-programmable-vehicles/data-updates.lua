--require("prototypes/entity/entity-update-externals")
--require("prototypes/entity/entity-update")

--log( serpent.block( data.raw["car"], {comment = false, numformat = '%1.8g' } ) )
