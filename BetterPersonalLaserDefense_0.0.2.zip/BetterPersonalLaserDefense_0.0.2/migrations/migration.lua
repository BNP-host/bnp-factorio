for index, force in pairs(game.forces) do
	local tech = force.technologies
	local recipes = force.recipes
 
	if tech["personal-laser-defense-equipment"] and tech["personal-laser-defense-equipment"].researched then
		recipes["laser-mk1s"].enabled = true
    end
end