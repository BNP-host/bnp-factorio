-- item.laser

-- mk1s

local lasermk1s =  table.deepcopy(data.raw["item"]["personal-laser-defense-equipment"]) 

lasermk1s.name = "laser-mk1s"
lasermk1s.icon = "__BetterPersonalLaserDefense__/graphics/icons/laser-mk1s.png"
lasermk1s.order = "b[active-defense]-a[personal-laser-defense-equipment]1"
lasermk1s.placed_as_equipment_result = "laser-mk1s"

-- mk2

local lasermk2 =  table.deepcopy(data.raw["item"]["personal-laser-defense-equipment"]) 

lasermk2.name = "laser-mk2"
lasermk2.icon = "__BetterPersonalLaserDefense__/graphics/icons/laser-mk2.png"
lasermk2.order = "b[active-defense]-a[personal-laser-defense-equipment]2"
lasermk2.placed_as_equipment_result = "laser-mk2"

-- mk2s

local lasermk2s =  table.deepcopy(data.raw["item"]["personal-laser-defense-equipment"]) 

lasermk2s.name = "laser-mk2s"
lasermk2s.icon = "__BetterPersonalLaserDefense__/graphics/icons/laser-mk2s.png"
lasermk2s.order = "b[active-defense]-a[personal-laser-defense-equipment]3"
lasermk2s.placed_as_equipment_result = "laser-mk2s"

-- mk3

local lasermk3 =  table.deepcopy(data.raw["item"]["personal-laser-defense-equipment"]) 

lasermk3.name = "laser-mk3"
lasermk3.icon = "__BetterPersonalLaserDefense__/graphics/icons/laser-mk3.png"
lasermk3.order = "b[active-defense]-a[personal-laser-defense-equipment]4"
lasermk3.placed_as_equipment_result = "laser-mk3"

-- mk3s

local lasermk3s =  table.deepcopy(data.raw["item"]["personal-laser-defense-equipment"]) 

lasermk3s.name = "laser-mk3s"
lasermk3s.icon = "__BetterPersonalLaserDefense__/graphics/icons/laser-mk3s.png"
lasermk3s.order = "b[active-defense]-a[personal-laser-defense-equipment]5"
lasermk3s.placed_as_equipment_result = "laser-mk3s"

data:extend{lasermk1s, lasermk2, lasermk2s, lasermk3, lasermk3s}