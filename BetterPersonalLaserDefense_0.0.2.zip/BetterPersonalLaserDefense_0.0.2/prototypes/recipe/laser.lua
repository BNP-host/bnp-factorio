-- recipe.laser

data:extend({

--mk1s

{
	type = "recipe",
	name = "laser-mk1s",
	result = "laser-mk1s",
	enabled = false,
	energy_required = 2,
	result_count = 4,
	
	ingredients = {
		{"personal-laser-defense-equipment", 1}
	}
},

-- mk2
{
	type = "recipe",
	name = "laser-mk2",
	result = "laser-mk2",
	enabled = false,
	energy_required = 30,
	
	ingredients = {
		{"personal-laser-defense-equipment", 4},
		{"battery-equipment", 10},
		{"fusion-reactor-equipment", 1},
		{"speed-module", 20},
		{"effectivity-module", 20}
	}
},

-- mk2s
{
	type = "recipe",
	name = "laser-mk2s",
	result = "laser-mk2s",
	enabled = false,
	energy_required = 2,
	result_count = 4,
	
	ingredients = {
		{"laser-mk2", 1}
	}
},

-- mk3
{
	type = "recipe",
	name = "laser-mk3",
	result = "laser-mk3",
	enabled = false,
	energy_required = 60,
	
	ingredients = {
		{"laser-mk2", 2},
		{"battery-mk2-equipment", 5},
		{"speed-module-3", 5},
		{"effectivity-module-3", 5}
	}
},

-- mk3s
{
	type = "recipe",
	name = "laser-mk3s",
	result = "laser-mk3s",
	enabled = false,
	energy_required = 2,
	result_count = 4,
	
	ingredients = {
		{"laser-mk3", 1}
	}
},

})