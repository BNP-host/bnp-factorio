-- equipment.laser

-- mk1s

local lasermk1s =  table.deepcopy(data.raw["active-defense-equipment"]["personal-laser-defense-equipment"])
lasermk1s.name = "laser-mk1s"

lasermk1s.attack_parameters.cooldown = 160
lasermk1s.attack_parameters.ammo_type.action.action_delivery.duration = 160

lasermk1s.shape = {
	type = "full",
	height = 1,
	width = 1
}

-- mk2

local lasermk2 =  table.deepcopy(data.raw["active-defense-equipment"]["personal-laser-defense-equipment"])
lasermk2.name = "laser-mk2"

lasermk2.sprite.filename = "__BetterPersonalLaserDefense__/graphics/equipment/laser-mk2.png"
lasermk2.sprite.hr_version.filename = "__BetterPersonalLaserDefense__/graphics/equipment/hr-laser-mk2.png"

lasermk2.attack_parameters.range = 30
lasermk2.attack_parameters.ammo_type.action.action_delivery.max_length = 30

lasermk2.attack_parameters.cooldown = 30
lasermk2.attack_parameters.ammo_type.action.action_delivery.duration = 30

lasermk2.attack_parameters.damage_modifier = 4

lasermk2.attack_parameters.ammo_type.energy_consumption = "37.5kJ"
lasermk2.energy_source.buffer_capacity = "420kJ"

-- mk2s

local lasermk2s =  table.deepcopy(data.raw["active-defense-equipment"]["personal-laser-defense-equipment"])
lasermk2s.name = "laser-mk2s"

lasermk2s.sprite.filename = "__BetterPersonalLaserDefense__/graphics/equipment/laser-mk2.png"
lasermk2s.sprite.hr_version.filename = "__BetterPersonalLaserDefense__/graphics/equipment/hr-laser-mk2.png"

lasermk2s.attack_parameters.range = 30
lasermk2s.attack_parameters.ammo_type.action.action_delivery.max_length = 30

lasermk2s.attack_parameters.cooldown = 120
lasermk2s.attack_parameters.ammo_type.action.action_delivery.duration = 120

lasermk2s.attack_parameters.damage_modifier = 4

lasermk2s.attack_parameters.ammo_type.energy_consumption = "37.5kJ"
lasermk2s.energy_source.buffer_capacity = "420kJ"

lasermk2s.shape = {
	type = "full",
	height = 1,
	width = 1
}

--mk3

local lasermk3 =  table.deepcopy(data.raw["active-defense-equipment"]["personal-laser-defense-equipment"])
lasermk3.name = "laser-mk3"

lasermk3.sprite.filename = "__BetterPersonalLaserDefense__/graphics/equipment/laser-mk3.png"
lasermk3.sprite.hr_version.filename = "__BetterPersonalLaserDefense__/graphics/equipment/hr-laser-mk3.png"

lasermk3.attack_parameters.range = 50
lasermk3.attack_parameters.ammo_type.action.action_delivery.max_length = 50

lasermk3.attack_parameters.cooldown = 20
lasermk3.attack_parameters.ammo_type.action.action_delivery.duration = 20

lasermk3.attack_parameters.damage_modifier = 5

lasermk3.attack_parameters.ammo_type.energy_consumption = "25kJ"
lasermk3.energy_source.buffer_capacity = "420kJ"

--mk3s

local lasermk3s =  table.deepcopy(data.raw["active-defense-equipment"]["personal-laser-defense-equipment"])
lasermk3s.name = "laser-mk3s"

lasermk3s.sprite.filename = "__BetterPersonalLaserDefense__/graphics/equipment/laser-mk3.png"
lasermk3s.sprite.hr_version.filename = "__BetterPersonalLaserDefense__/graphics/equipment/hr-laser-mk3.png"

lasermk3s.attack_parameters.range = 50
lasermk3s.attack_parameters.ammo_type.action.action_delivery.max_length = 50

lasermk3s.attack_parameters.cooldown = 80
lasermk3s.attack_parameters.ammo_type.action.action_delivery.duration = 80

lasermk3s.attack_parameters.damage_modifier = 5

lasermk3s.attack_parameters.ammo_type.energy_consumption = "25kJ"
lasermk3s.energy_source.buffer_capacity = "420kJ"

lasermk3s.shape = {
	type = "full",
	height = 1,
	width = 1
}


data:extend{lasermk1s, lasermk2, lasermk2s, lasermk3, lasermk3s}