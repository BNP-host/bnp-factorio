-- technology.laser

--mk1s

table.insert(data.raw["technology"]["personal-laser-defense-equipment"].effects, {type = "unlock-recipe",recipe = "laser-mk1s"})

data:extend({

-- mk2

{
	type = "technology",
	name = "laser-mk2",
	
	icon_mipmaps = 4,
	icon_size = 256,
	
	icons = {
		{
			icon = "__BetterPersonalLaserDefense__/graphics/technology/laser-mk2.png",
			icon_mipmaps = 4,
			icon_size = 256
		},
		{
			icon = "__core__/graphics/icons/technology/constants/constant-equipment.png",
			icon_mipmaps = 3,
			icon_size = 128,
			shift = {100,100}
		}
	},
	
	prerequisites = {"personal-laser-defense-equipment"},
	
	effects = {
		{
			type = "unlock-recipe",
			recipe = "laser-mk2"
		},
		{
			type = "unlock-recipe",
			recipe = "laser-mk2s"
		},
		
    },
	
	unit = {
		count = 1000,
		ingredients = {
			{"automation-science-pack",1},
			{"logistic-science-pack",1},
			{"chemical-science-pack",1},
			{"military-science-pack",1},
			{"utility-science-pack",1}
			
		},
		time = 30
	}
	
},

-- mk3

{
	type = "technology",
	name = "laser-mk3",
	
	icon_mipmaps = 4,
	icon_size = 256,
	
	icons = {
		{
			icon = "__BetterPersonalLaserDefense__/graphics/technology/laser-mk3.png",
			icon_mipmaps = 4,
			icon_size = 256
		},
		{
			icon = "__core__/graphics/icons/technology/constants/constant-equipment.png",
			icon_mipmaps = 3,
			icon_size = 128,
			shift = {100,100}
		}
	},
	
	prerequisites = {"laser-mk2"},
	
	effects = {
		{
			type = "unlock-recipe",
			recipe = "laser-mk3"
		},
		{
			type = "unlock-recipe",
			recipe = "laser-mk3s"
		}
    },
	
	unit = {
		count = 10000,
		ingredients = {
			{"automation-science-pack",1},
			{"logistic-science-pack",1},
			{"chemical-science-pack",1},
			{"military-science-pack",1},
			{"utility-science-pack",1},
			{"space-science-pack",1}
		},
		time = 60
	}
	
}

})