require("prototypes.item.laser")
require("prototypes.equipment.laser")
require("prototypes.recipe.laser")
require("prototypes.technology.laser")