require("prototypes/shield-projector")
require("prototypes/input")