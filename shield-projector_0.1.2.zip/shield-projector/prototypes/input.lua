data:extend{
    {
      type = 'custom-input',
      name = 'shield-projector-mode-toggle',
      key_sequence = "R",
      enabled_while_spectating = true,
      order = "a-d",
  },
}