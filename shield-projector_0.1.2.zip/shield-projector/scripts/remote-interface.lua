remote.add_interface(
    "shield-projector",
    {
        get_sub_entity_names = function()
          return ShieldProjector.get_sub_entity_names()
        end,

        find_on_surface = function(data)
          return ShieldProjector.find_on_surface(data.surface, data.area)
        end,
    }
)
