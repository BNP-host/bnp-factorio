local Shared = {}
-- used in data phase and control

Shared.spaceship_victory_speed = 250
Shared.spaceship_victory_duration = 600

Shared.resources_with_shared_controls = {
 "lithia-water", --uses ground-water
}

return Shared
