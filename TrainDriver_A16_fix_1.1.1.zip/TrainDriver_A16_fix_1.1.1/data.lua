require("prototypes/hotkey")
