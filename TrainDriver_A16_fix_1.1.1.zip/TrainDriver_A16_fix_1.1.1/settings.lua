data:extend{
	{
		type = "bool-setting",
		name = "train_driver_show_straight",
		setting_type = "runtime-per-user",
		order = "a",
		default_value = true
	}
}