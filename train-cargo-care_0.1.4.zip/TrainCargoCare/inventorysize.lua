--inventorysize.lua

data.raw["cargo-wagon"]["cargo-wagon"].inventory_size = 80
data.raw["car"]["car"].inventory_size = 40