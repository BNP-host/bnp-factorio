local chases_belt_items = settings.startup["inserter-config-chase-belt-items"].value

for i, inserter in pairs(data.raw.inserter) do
	inserter.allow_custom_vectors = true
	inserter.extension_speed = inserter.extension_speed * 2
	inserter.chases_belt_items = chases_belt_items
end