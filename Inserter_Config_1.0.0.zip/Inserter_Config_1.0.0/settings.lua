data:extend({
    {
        type = "bool-setting",
        setting_type = "startup",
        name = "inserter-config-chase-belt-items",
        default_value  = true
    }
})