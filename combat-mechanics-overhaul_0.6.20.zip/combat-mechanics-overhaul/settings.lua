data:extend{
  {
      type = "bool-setting",
      name = "walls-block-compensation",
      setting_type = "startup",
      default_value = true,
  },
  {
      type = "bool-setting",
      name = "spitter-spit-blockable",
      setting_type = "startup",
      default_value = true,
  },
  {
      type = "bool-setting",
      name = "worm-spit-blockable",
      setting_type = "startup",
      default_value = true,
  },
  {
      type = "bool-setting",
      name = "rockets-blockable",
      setting_type = "startup",
      default_value = true,
  },
  {
      type = "bool-setting",
      name = "pools-affect-structures",
      setting_type = "startup",
      default_value = false,
  },
  {
      type = "bool-setting",
      name = "pools-affect-flying",
      setting_type = "startup",
      default_value = false,
  },
  {
      type = "bool-setting",
      name = "shotguns-hit-friendly",
      setting_type = "startup",
      default_value = false,
  },
}
