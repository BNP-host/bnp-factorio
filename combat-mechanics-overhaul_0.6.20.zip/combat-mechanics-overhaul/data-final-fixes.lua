collision_mask_util_extended = require("__combat-mechanics-overhaul__/collision-mask-util-extended/data/collision-mask-util-extended")
require("prototypes/phase-3/collision-common")
require("prototypes/phase-3/collision-trigger-types")
