data:extend(
    {
        {
            type = 'bool-setting',
            name = 'result_enabled',
            setting_type = 'startup',
            default_value = 1,
            order = 'a'
        },
        {
            type = 'bool-setting',
            name = 'stack_enabled',
            setting_type = 'startup',
            default_value = 1,
            order = 'b'
        },
        {
            type = 'bool-setting',
            name = 'oil_enabled',
            setting_type = 'startup',
            default_value = 1,
            order = 'c'
        },
        {
            type = 'bool-setting',
            name = 'multiple_enabled',
            setting_type = 'startup',
            default_value = 1,
            order = 'd'
        },
        {
            type = 'int-setting',
            name = 'result',
            setting_type = 'startup',
            default_value = 1,
            maximum_value = 1000,
            minimum_value = 1,
            order = 'e'
        },
        {
            type = 'int-setting',
            name = 'stack_size',
            setting_type = 'startup',
            default_value = 5000,
            maximum_value = 10000,
            minimum_value = 100,
            order = 'f'
        },
        {
            type = 'int-setting',
            name = 'oil-result',
            setting_type = 'startup',
            default_value = 1,
            maximum_value = 10,
            minimum_value = 1,
            order = 'g'
        }
    }
)
