local result_enabled = settings.startup['result_enabled'].value
local stack_enabled = settings.startup['stack_enabled'].value
local oil_enabled = settings.startup['oil_enabled'].value
local multiple_enabled = settings.startup['multiple_enabled'].value

local result_size = settings.startup['result'].value
local stack_size = settings.startup['stack_size'].value
local oil_size = settings.startup['oil-result'].value

local types = {
    'item',
    'ammo',
    'gun',
    'capsule',
    'repair-tool',
    'item-with-entity-data',
    'rail-planner',
    'recipe',
    'tool',
    'module'
}

local function final_result(r)
    if not r.result then
        return
    end
    local result_count = r.result_count or 1
    if type(r.result) == 'string' then
        r.results = {{type = 'item', name = r.result, amount = result_count}}
    elseif r.result.name then
        r.results = {r.result}
    elseif r.result[1] then
        result_count = r.result[2] or result_count
        r.results = {{type = 'item', name = r.result[1], amount = result_count}}
    end
    r.result = nil
end

local function final_update(tbl)
    if data.raw[tbl.type] and data.raw[tbl.type][tbl.name] then
        local raw = data.raw[tbl.type][tbl.name]
        if not raw.normal then
            raw.normal = {
                enabled = raw.enabled,
                energy_required = raw.energy_required,
                requester_paste_multiplier = raw.requester_paste_multiplier,
                hidden = raw.hidden,
                ingredients = raw.ingredients,
                results = raw.results,
                result = raw.result,
                result_count = raw.result_count
            }
            raw.enabled = nil
            raw.energy_required = nil
            raw.requester_paste_multiplier = nil
            raw.hidden = nil
            raw.ingredients = nil
            raw.results = nil
            raw.result = nil
            raw.result_count = nil
        end

        if not raw.expensive then
            raw.expensive = table.deepcopy(raw.normal)
        end
        if not raw.normal.results and raw.normal.result then
            final_result(raw.normal)
        end
        if not raw.expensive.results and raw.expensive.result then
            final_result(raw.expensive)
        end

        for key, property in pairs(tbl) do
            if key == 'ingredients' then
                raw.normal.ingredients = table.deepcopy(property)
                raw.expensive.ingredients = table.deepcopy(property)
            elseif key == 'results' then
                raw.normal.results = table.deepcopy(property)
                raw.expensive.results = table.deepcopy(property)
            elseif key ~= 'normal' and key ~= 'expensive' then
                raw[key] = property
            end
        end

        if tbl.normal then
            for key, property in pairs(tbl.normal) do
                raw.normal[key] = property
            end
        end

        if tbl.expensive then
            for key, property in pairs(tbl.expensive) do
                raw.expensive[key] = property
            end
        end
    end
end

local function fix_amount(item)
    if not item.result_count then
        item.result_count = result_size
    elseif item.result_count then
        if multiple_enabled then
            item.result_count = item.result_count + result_size
        else
            item.result_count = result_size
        end
    end
    if item.results then
        for i, r in pairs(item.results) do
            if r.amount then
                if multiple_enabled then
                    r.amount = r.amount + result_size
                else
                    r.amount = result_size
                end
            elseif r.amount_min then
                r.amount_min = r.amount_min + result_size
            elseif r.amount_max then
                r.amount_max = r.amount_max + result_size
            end
        end
    end
end

local function is_stackable(item)
    if not item.flags then
        return true
    end
    if type(item.flags) ~= 'table' then
        return true
    end
    for _, v in pairs(item.flags) do
        if v == 'not-stackable' then
            return false
        end
    end
    return true
end

local ignore_list = {}

for _, dat in pairs(data.raw) do
    for name, item in pairs(dat) do
        if not is_stackable(item) then
            ignore_list[name] = true
        end
        if item.type == 'armor' then
            ignore_list[name] = true
        end
    end
end

for _, resource in pairs(types) do
    local prot_type = data.raw[resource]
    for name, item in pairs(prot_type) do
        if not ignore_list[name] then
            if result_enabled then
                if item then
                    if item.normal and item.expensive then
                        fix_amount(item.normal)
                        fix_amount(item.expensive)
                    end
                    fix_amount(item)
                end
            end

            if stack_enabled then
                if item.stack_size and item.stack_size > 1 then
                    if type(item.stack_size) == 'number' then
                        item.stack_size = stack_size
                        item.default_request_amount = 10
                    end
                end
            end
        end
    end
end

if oil_enabled then
    final_update(
        {
            type = 'recipe',
            name = 'basic-oil-processing',
            results = {
                {type = 'fluid', name = 'petroleum-gas', amount = 45 * oil_size}
            }
        }
    )
    final_update(
        {
            type = 'recipe',
            name = 'advanced-oil-processing',
            results = {
                {type = 'fluid', name = 'heavy-oil', amount = 25 * oil_size},
                {type = 'fluid', name = 'light-oil', amount = 45 * oil_size},
                {type = 'fluid', name = 'petroleum-gas', amount = 55 * oil_size}
            }
        }
    )
    final_update(
        {
            type = 'recipe',
            name = 'coal-liquefaction',
            results = {
                {type = 'fluid', name = 'heavy-oil', amount = 90 * oil_size},
                {type = 'fluid', name = 'light-oil', amount = 20 * oil_size},
                {type = 'fluid', name = 'petroleum-gas', amount = 10 * oil_size}
            }
        }
    )
end
