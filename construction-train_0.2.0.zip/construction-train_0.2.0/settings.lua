data:extend({
  {
    type = "string-setting",
    name = "ct-default-cargo-mode",
    setting_type = "runtime-per-user",
    default_value = "full",
    allowed_values = {"full", "disabled", "fill", "empty"}
  }
})