require "prototypes/construction_wagon"
