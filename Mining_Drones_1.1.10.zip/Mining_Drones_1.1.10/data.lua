util = require "data/tf_util/tf_util"
names = require("shared")
shared = require("shared")

require "data/entities/entities"
require "data/technologies/mining_speed"
require "data/technologies/mining_productivity"

data.raw["gui-style"].default.machine_outputs_scroll_pane.maximal_height = 150