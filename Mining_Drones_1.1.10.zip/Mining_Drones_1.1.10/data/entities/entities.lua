local require = function(name) return require("data/entities/"..name) end

require("mining_drone/mining_drone")
require("proxy_chest/proxy_chest")
require("mining_depot/mining_depot")