data:extend({
  {
    type = "bool-setting",
    name = "mute_drones",
    setting_type = "startup",
    localised_name = "Mute drone sounds",
    default_value = false
  },
})
