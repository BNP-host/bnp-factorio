local locomotives_and_wagons_entities_table = {
    data.raw['locomotive'],
    data.raw['cargo-wagon'],
    data.raw['fluid-wagon'],
    data.raw['artillery-wagon'],
}

for _, train_table in ipairs( locomotives_and_wagons_entities_table ) do
    for _, train_entity in pairs( train_table ) do
        train_entity.resistances = train_entity.resistances or {}
        table.insert(train_entity.resistances, {type = "fire", percent = 100})
    end
end
