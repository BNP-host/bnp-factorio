This is a rework of the original mod by SilentSean (https://mods.factorio.com/user/SilentSean) by b4Bu aka nEbul4.

At the moment he seems to have abandonned the project, so I "ported" it to V1.1.X.

I used most of his codebase, but changed all the costs, recipes and capabilities of the roboports. They are more expensive, and have more charging ports. 

Pictures are the original gamefiles, but modified to give a easier visual distinction between the different tiers of roboports. MK2 is Red, MK3 is green.
Images are modified by my friend https://github.com/Haeki

A couple of friends and me changed basically all of the settings to make it more fitting with our playstyle, but like this they seem a little strong. Please give me some input if you got any.

To me its fine to modify all of this, hence the MIT license.