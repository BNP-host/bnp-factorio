-- Definition de RitnLib
-- Accessibilité des functions depuis un autres mods
require("defines")