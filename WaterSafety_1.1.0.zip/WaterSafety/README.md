# Water Safety
A mod for the game Factorio. 

Modifies all water-placing items (only available with mods) to place shallow water initially, which is instantly converted to the correct water types. As a result, such items can't kill characters or creatures (these may become trapped instead), and placing water under a player isn't deadly anymore. 

Also adds a basic waterfill item with recipe that can be disabled in the settings. 

The last feature is swimming for player characters: If enabled, walking across water is individually possible. 
