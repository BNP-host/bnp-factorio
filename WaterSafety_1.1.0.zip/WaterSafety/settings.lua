data:extend({
    {
        type = "bool-setting",
        name = "WaterSafety-enable-waterfill",
        setting_type = "startup",
        default_value = true,
        order = "a-a"
    },
    
    {
        type = "bool-setting",
        name = "WaterSafety-enable-swimming",
        setting_type = "runtime-per-user",
        default_value = true,
        order = "a-a"
    }
})
