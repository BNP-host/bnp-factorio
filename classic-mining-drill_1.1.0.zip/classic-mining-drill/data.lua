-- Copyright (c) 2020 Kirazy
-- Part of Classic Mining Drill
--
-- See LICENSE.md in the project directory for license information.

require("prototypes.electric-mining-drill")