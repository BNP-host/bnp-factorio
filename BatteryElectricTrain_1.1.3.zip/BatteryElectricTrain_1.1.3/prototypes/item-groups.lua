data:extend(
{
	{	type = "item-subgroup",
		name = name_group_chargers,
		group = "logistics",
		order = "ez",
	},
	{
		type = "item-subgroup",
		name = name_group_batteries,
		group = "intermediate-products",
		order = "fa",
	}
})
