data:extend({
	{
		type = "fuel-category",
		name = name_cat_fuel_battery
	},
	{
		type = "recipe-category",
		name = name_cat_recipe_chg
	}
})

