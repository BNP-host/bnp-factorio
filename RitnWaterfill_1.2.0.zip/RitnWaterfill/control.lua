if not global.players then global.players = {} end




script.on_event(defines.events.on_player_cursor_stack_changed, function(e)
    local LuaPlayer = game.players[e.player_index]
    local LuaSurface = LuaPlayer.surface

    if game.active_mods["vadatajs_landfill_removal"] then

        if not global.players[LuaPlayer.name] then global.players[LuaPlayer.name] = {
                    surfaces = {}
        } end
        if not global.players[LuaPlayer.name].surfaces[LuaSurface.name] then global.players[LuaPlayer.name].surfaces[LuaSurface.name] = {
            count = 0,
            value = 0
        } end

        if LuaPlayer.cursor_stack ~= nil then
            pcall(function()
                if LuaPlayer.cursor_stack.name == "waterfill" then
                    global.players[LuaPlayer.name].surfaces[LuaSurface.name].count = LuaPlayer.cursor_stack.count
                    --LuaPlayer.print(LuaSurface.name .. " : " .. global.players[LuaPlayer.name].surfaces[LuaSurface.name].count)
                end
            end)
        end
    end

end)




script.on_event(defines.events.on_player_built_tile, function(e)
    if game.active_mods["vadatajs_landfill_removal"] then
        local setting_value = settings.global["ritnmods-waterfill-01"].value
        if setting_value == true then
            local LuaPlayer = game.players[e.player_index]
            local LuaSurface = game.surfaces[e.surface_index]
            local LuaTilePrototype = e.tile
            local LuaItemPrototype = e.item
            local LuaItemStack = e.stack

            if  LuaItemPrototype.name == "waterfill" then
                if LuaPlayer.cursor_stack ~= nil then
                    pcall(function()
                        if LuaPlayer.cursor_stack.name == "waterfill" then
                            local count = global.players[LuaPlayer.name].surfaces[LuaSurface.name].count
                            local value = LuaPlayer.cursor_stack.count
                            --LuaPlayer.print("count : " .. count)
                            --LuaPlayer.print("value : " .. value)
                            if value > count then value = value - count else value = count - value end
                            --LuaPlayer.print("value : " .. value)
                            global.players[LuaPlayer.name].surfaces[LuaSurface.name].value = 
                                global.players[LuaPlayer.name].surfaces[LuaSurface.name].value + value

                            --LuaPlayer.print("Stack : " .. LuaItemStack.name .. " = " .. global.players[LuaPlayer.name].surfaces[LuaSurface.name].value)
                        end
                    end)
                end
            end

        end
    end
end) 


script.on_event(defines.events.on_tick, function(e)

    if game.active_mods["vadatajs_landfill_removal"] then
        local players = #game.players + 1
        local index = e.tick % players

        if index ~= 0 then 
            local LuaPlayer = game.players[index]
            if LuaPlayer == nil then return end
            local LuaSurface = LuaPlayer.surface
            if LuaSurface == nil then return end

            if not global.players[LuaPlayer.name] then global.players[LuaPlayer.name] = {
                surfaces = {}
            } end
            if not global.players[LuaPlayer.name].surfaces[LuaSurface.name] then global.players[LuaPlayer.name].surfaces[LuaSurface.name] = {
                count = 0,
                value = 0
            } end

            local waterfill_value = settings.global["ritnmods-waterfill-02"].value
            local landfill_value = settings.global["ritnmods-waterfill-03"].value

            if global.players[LuaPlayer.name].surfaces[LuaSurface.name].value >= waterfill_value then 
                global.players[LuaPlayer.name].surfaces[LuaSurface.name].value =
                    global.players[LuaPlayer.name].surfaces[LuaSurface.name].value - waterfill_value
                    --LuaPlayer.print("suppr, value = " .. global.players[LuaPlayer.name].surfaces[LuaSurface.name].value)
                if LuaPlayer.can_insert({name="landfill", count=landfill_value}) then 
                    LuaPlayer.insert({name="landfill", count=landfill_value})
                end
            end

        end
    end
    
end)