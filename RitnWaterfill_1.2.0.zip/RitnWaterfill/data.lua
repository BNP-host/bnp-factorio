-- INITIALIZE
-----------------------------------------------------------------
local libMod = "__RitnLib__"
ritnlib = {}
--ritnlib.util    = require(libMod .. ".lualib.other-functions")
--ritnlib.ore     = require(libMod .. ".lualib.ore-functions")
--ritnlib.item    = require(libMod .. ".lualib.item-functions")
--ritnlib.recipe  = require(libMod .. ".lualib.recipe-functions")
ritnlib.tech    = require(libMod .. ".lualib.technology-functions")
-----------------------------------------------------------------
if not ritnmods then ritnmods = {} end
if not ritnmods.waterfill then ritnmods.waterfill = {} end


require("prototypes.items")
require("prototypes.technologies")


if mods["vadatajs_landfill_removal"] then 
  ritnlib.tech.prerequisite.remove("waterfill", "landfill")
  ritnlib.tech.prerequisite.add("waterfill", "logistic-science-pack")
  ritnlib.tech.pack.multiplied("waterfill", 2)
end