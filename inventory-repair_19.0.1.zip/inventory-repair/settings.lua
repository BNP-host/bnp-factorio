--[[
data:extend({ 	

	-- runtime global
   {
		type = "string-setting",
		name = "inventory-repair-mode",
		setting_type = "runtime-global",
		allowed_values = {"balanced", "instant"},
		default_value = "balanced",
		allow_blank = false,
		order = "a[mode]",
	},
})
]]