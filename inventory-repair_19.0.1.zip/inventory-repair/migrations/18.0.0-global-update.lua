
global.players = global.players or {}