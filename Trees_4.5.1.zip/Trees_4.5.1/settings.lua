
local function Setting(s)
    s.name = "Trees-" .. s.name
    s.type = s.type .. "-setting"
    s.setting_type = "runtime-global"
    return s
end

data:extend({


    Setting{ type = "int",
        name = 'rate',
        minimum_value = 1,
        default_value = 230,
    },

    Setting{ type = "int",
        name = 'radius',
        minimum_value = 1,
        default_value = 64,
    },

    Setting{ type = "double",
        name = 'color-variance',
        minimum_value = 0,
        maximum_value = 1,
        default_value = 0.2,
    },


})
