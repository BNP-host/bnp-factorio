local bigunpack = require("__big-data-string__.unpack")
local peak = require("lib.peak")

local inf =  1/0

--------------------------------------------------------------------------------

local function isempty(t) return not next(t) end
local function get(t,k,d) return t[k] or d end
local function set(t,k,v) t[k] = v return t end

local function fold(t,f,s)
    for k,v in pairs(t) do s = f(s,k,v) end return s
end

local function map(t,f)
    return fold(t,function (t,k,v) return set(t,k,f(v)) end,{})
end

local function filter(t,f)
    local r = {} for _,v in pairs(t) do if f(v) then table.insert(r,v) end end return r
end

local function contains(t,x)
    for k,v in pairs(t) do if v == x then return true end end return false
end

local function split(s,d)
    local r = {} for x in string.gmatch(s,"[^" .. d .. "]+") do table.insert(r,x) end return r
end

local function const(c) return {x=c, y=c} end
local function vec(x,y) return {x=x, y=y} end
local function add(a,b) return {x=a.x+b.x, y=a.y+b.y} end
local function sub(a,b) return {x=a.x-b.x, y=a.y-b.y} end
local function mul(a,b) return {x=a.x*b.x, y=a.y*b.y} end
local function rot(v,a) local c,s = math.cos(a),math.sin(a) return {x=v.x*c-v.y*s, y=v.x*s+v.y*c} end
local function ori(o) return rot(vec(0,-1), o*2*math.pi) end
local function ensure_vec(v) return type(v) ~= 'table' and vec(inf,inf) or vec(v.x or v[1] or inf, v.y or v[2] or inf) end


local STORE = {} -- memoize
local function memo(f,...)
    return STORE[f] or set(STORE,f,f(...))[f]
end

--------------------------------------------------------------------------------

local Cache = {}
Cache.data = nil -- filled by on_load

function Cache.reindex()
    Cache.index = {}
    Cache.data = global.cache
    for id,values in pairs(Cache.data and Cache.data.values or {}) do
        local index = {} -- restore
        Cache.index[id] = index
        for _,value in pairs(values) do
            index[value.i] = value
        end
    end
end

function Cache.create()
    local cache = {
        counts = {},
        values = {},
    }
    -- internalize
    Cache.index = {}
    Cache.data = cache
    global.cache = cache
    return cache
end

function Cache.get(index)
    return Cache.data.values[index], Cache.data.counts[index]
end

function Cache.list(index)
    return Cache.index[index], Cache.data.counts[index]
end

function Cache.reset(index)
    local values = {}
    Cache.data.counts[index] = 0
    Cache.data.values[index] = values
    Cache.index      [index] = {}
    return values,0
end

function Cache.delete(index)
    Cache.data.counts[index] = nil
    Cache.data.values[index] = nil
    Cache.index      [index] = nil
end

function Cache.store(index, key, position)
    local array, values, count = Cache.list(index), Cache.get(index)
    if position then -- add
        local value = ensure_vec(position)
        if values[key] then
            value.i = values[key].i
        else
            value.i = 1+#array
            count = count + 1
            Cache.data.counts[index] = count
        end
        value.k = key
        array[value.i] = value
        values[key] = value
    elseif values[key] then -- remove
        local i,l = values[key].i,#array
        count = count - 1
        Cache.data.counts[index] = count
        array[l].i = i
        array[i] = array[l]
        array[l] = nil
        values[key] = nil
    end
    return values, count
end

--------------------------------------------------------------------------------

local function decode(s)
    return map(split(s or "",","), tonumber)
end

local CACHE = {}
local function get_lying_tree_indexes(entity)
    local name = entity.name
    local value = CACHE[name]
    if value then return value end
    value = decode(bigunpack("lying-tree-indexes-of-" .. name))
    CACHE[name] = value
    return value
end

local function is_lying_tree(entity)
    return contains(get_lying_tree_indexes(entity), entity.graphics_variation)
end

local function is_concrete(tile)
    return string.find(tile.name, "concrete")
end

local function is_autoplacable(entity)
    return not not entity.prototype.autoplace_specification
end

local function has_autoplacement(surface)
    local autoplace = surface.map_gen_settings.autoplace_controls
    return autoplace and autoplace["trees"]
end

local function is_tree(entity)
    return entity and entity.type == "tree"
end

local function is_dead_tree(entity)
    return string.find(entity.name, "dead")
        or string.find(entity.name, "dry")
end

local function is_propagable_tree(entity)
    return entity.tree_stage_index < entity.tree_stage_index_max / 2
end

local function is_placable_tree(entity)
    return is_tree(entity)
       and is_autoplacable(entity)
       and not is_dead_tree(entity)
end

local function placeable_tree_names()
    local function get_name(prototype) return prototype.name end
    local function is_alive(prototype) return not is_dead_tree(prototype) end
    return map(filter(game.get_filtered_entity_prototypes{
        {mode = 'and', filter = 'type', type = 'tree'},
        {mode = 'and', filter = 'autoplace'},
    }, is_alive), get_name)
end

local function random_variance(c,f,m)
    local v = math.ceil((global.random() * 2 - 1) * m * f)
    return ((c - 1 + v) % m) + 1
end

local function index_progress(entity, key)
    local i,m = entity[key .. '_index'], entity[key .. '_index_max']
    return m == 0 and 0 or i / m
end

--------------------------------------------------------------------------------

local function shuffle(t)
    return global.random(1, #t)
end

local function choice(t)
    return next(t) and t[shuffle(t)] or nil
end

local function pick(t,f)
    return choice(filter(t,f))
end

-- roulette knight -- https://fourquarters.itch.io/roulette-knight-ludum-dare-41
local function russian_roulette()
    return global.random() < 0.5 -- [0,1)
end -- listen Steam by FatGyver -- https://fanu.bandcamp.com/track/steam-2

local function create_random_position(...)
    return {x=global.random(...),y=global.random(...)}
end

local function wind_direction(surface, scale) local s = scale or 1
    return mul(ori(surface.wind_orientation), const(s*surface.wind_speed))
end

local function setting(key)
    return settings.global["Trees-" .. key].value
end

local function get_options() return {
    radius = setting'radius',
    name = memo(placeable_tree_names),
    type = 'tree',
} end

local function whole_surface(options, limit) return {
    type  = options.type,
    name  = options.name,
    limit = limit,
} end

local function at_position(options,position) return {
    position = position or options.position,
    type     = options.type,
    name     = options.name,
} end

local function at_area(options,area) return {
    area = area,
    type = options.type,
    name = options.name,
} end

local function find_random_entity_filtered(surface, options)
    local positions, count, _ = Cache.list(surface.index)
    if count <= 0 then return nil end
    while true do
        local position = choice(positions)
        if not position then return nil end
        local entities = surface.find_entities_filtered(at_position(options, position))
        if not isempty(entities) then
            return choice(entities)
        else -- found dead or non placeable location
            _, count = Cache.store(surface.index, position.k, nil)
            if count <= 0 then return nil end
        end
    end
end

local function get_spawn_options(surface)
    local options = get_options()
    local entity = find_random_entity_filtered(surface, options)
    options.position = entity and entity.position or options.position
    return options
end

local function get_age_options(surface)
    local options = get_spawn_options(surface)
    options.radius = math.sqrt(options.radius) / 2
    return options
end

local function find_random_entities_filtered(surface)
    local options = get_age_options(surface)
    if not options.position then return {} end
    return surface.find_entities_filtered(options)
end

--------------------------------------------------------------------------------

-- TODO integrate entity.health (aka damage of trees)

local function seed_configuration(surface, options)
    if not options.position then return nil end
    local entity = pick(surface.find_entities_filtered(options), is_propagable_tree)
    if not entity then return end
    local factor = index_progress(entity, 'tree_stage')
                 + index_progress(entity, 'tree_gray_stage')
    return entity.name, factor, entity.tree_color_index
end

local function grow_seed(surface,position,name,color)
    if peak.probability(surface,position,name) - global.random() > 0 then
        local entity = surface.create_entity{
            raise_built = true,
            position = position,
            name = name,
        }
        if not entity then return end
        entity.tree_color_index = random_variance(color,
            setting'color-variance', entity.tree_color_index_max)
    end
end

local F = 5
local function spawn_tree(surface)
    if not has_autoplacement(surface) then return end
    local options = get_spawn_options(surface)
    local name,f,color = seed_configuration(surface, options)
    if name then
        local r = (2 - f) * options.radius
        if r > 1 then
            local position = add(options.position, wind_direction(surface, r*F))
            position = add(position, create_random_position(-F,F))
            position = surface.find_non_colliding_position(name, position, r,1)
            if position then
                local tile = surface.get_tile(position.x, position.y)
                if tile and not is_concrete(tile) then
                    grow_seed(surface, position, name, color)
                end
            end
        end
    end
end

local function spawn_tree_on_all_surfaces()
    for _, surface in pairs(game.surfaces) do spawn_tree(surface) end
end

--------------------------------------------------------------------------------

local function progess_age_tree(entity)
    if entity.tree_stage_index < entity.tree_stage_index_max then
        if russian_roulette() then
            entity.tree_stage_index = entity.tree_stage_index + 1
        end
    else
        local indexes = get_lying_tree_indexes(entity)
        if isempty(indexes) then
            if russian_roulette() then entity.die() end
        elseif contains(indexes, entity.graphics_variation) then
            entity.destroy{raise_destroy=true}
        elseif russian_roulette() then
            entity.graphics_variation = choice(indexes) or entity.graphics_variation
        elseif russian_roulette() then
            entity.die()
        end
    end
end

local function age_tree(surface)
    if not has_autoplacement(surface) then return end
    for _, entity in pairs(find_random_entities_filtered(surface)) do
        if russian_roulette() then
            progess_age_tree(entity)
        end
    end
end

local function age_tree_on_all_surfaces()
    for _, surface in pairs(game.surfaces) do age_tree(surface) end
end

--------------------------------------------------------------------------------

local function update_trees_on_all_surfaces()
--     spawn_tree_on_all_surfaces()
--       age_tree_on_all_surfaces()
    for _, surface in pairs(game.surfaces) do
        spawn_tree(surface)
          age_tree(surface)
    end
end

script.on_event(defines.events.on_tick, function (event)
    if event.tick % setting'rate' == 0 then update_trees_on_all_surfaces() end
end)

--------------------------------------------------------------------------------

local function tree_hash(entity)
    return string.format("%s,%s", math.floor(entity.position.x), math.floor(entity.position.y))
end

local function add_tree_position(entity)
    local idx = entity.surface.index
    local key = tree_hash(entity)
    local num = script.register_on_entity_destroyed(entity)
    global.registration[num] = {i=idx, k=key}
    return Cache.store(idx, key, entity.position)
end

local function remove_tree_position(num)
    local reg = global.registration[num]
    if not reg then return end
    return Cache.store(reg.i, reg.k, nil)
end

local function get_all_tree_positions(surface)
    local options = whole_surface(get_options())
    return fold(surface.find_entities_filtered(options), function (positions, _, entity)
        return add_tree_position(entity)
    end, Cache.reset(surface.index))
end

local function add_tree_positions(surface, area)
    local options = at_area(get_options(), area)
    return fold(surface.find_entities_filtered(options), function (positions, _, entity)
        return add_tree_position(entity)
    end, Cache.get(surface.index))
end

local function get_all_positions()
    for _, surface in pairs(game.surfaces) do
        get_all_tree_positions(surface)
    end
end


--------------------------------------------------------------------------------

local events = {
    surface = {
        added = {
            defines.events.on_surface_created,
            defines.events.on_surface_imported,
        },
    },
    chunk = {
        added = {
            defines.events.on_chunk_generated,
        },
    },
    entity = {
        added = {
            defines.events.on_built_entity,
            defines.events.script_raised_built,
            defines.events.script_raised_revive,
            defines.events.on_robot_built_entity,
        },
    },
    trigger = {
        added = {
            defines.events.on_trigger_created_entity,
        },
        removed = {
            defines.events.on_entity_destroyed,
        },
    },
}

local filters = {
    {filter="type", type="tree"},
}


script.on_init(function ()
    global.registration = {}
    global.cache  = Cache.create()
    global.random = game.create_random_generator()
    get_all_positions() -- this is before on_load
end)

script.on_load(Cache.reindex)

script.on_configuration_changed(function ()
    global.registration = {}
    global.cache = Cache.create()
    get_all_positions()
end)


script.on_event(events.surface.added, function (event)
    get_all_tree_positions(game.surfaces[event.surface_index])
end)


script.on_event(events.chunk.added, function (event)
    add_tree_positions(event.surface, event.area)
end)


script.on_event(events.entity.added, function (event)
    add_tree_position(event.created_entity or event.entity)
end)

for _,events in pairs(events.entity) do
    for _,event in ipairs(events) do
        script.set_event_filter(event, filters)
    end
end


script.on_event(events.trigger.added, function (event)
    if not is_placable_tree(event.entity) then return end
    add_tree_position(event.entity)
end)


script.on_event(events.trigger.removed, function (event)
    remove_tree_position(event.registration_number)
end)



