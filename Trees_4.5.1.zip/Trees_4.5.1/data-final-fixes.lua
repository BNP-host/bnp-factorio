local bigpack = require("__big-data-string__.pack")


-- HACK to get values from data.raw into scripting


local function map(t,f)
    local r = {} for k,v in pairs(t) do r[k] = f(v) end return r
end

local function layer_fmap(anim,f)
    for _,layer in pairs(anim.layers or {anim}) do
        if layer.layers then
            if layer_fmap(layer,f) then return true end
        else
            if f(layer) then return true end
        end
    end
    return false
end

local function sprites(pictures)
    return pictures.filename and {pictures} or pictures
end

local function size(layer,i)
    return type(layer.size) == 'table' and layer.size[i] or layer.size
end

local function dimension(layer)
    local w,h,s = layer.width  or size(layer,1),
                  layer.height or size(layer,2),
                  layer.shift  or {0,0}
    return w - s[1] * 32, h - s[2] * 32
end

local function is_vertical(w,h)
    return h / w > 1.02
end

local function is_lighting(layer)
    return layer.draw_as_shadow
        or layer.draw_as_glow
        or layer.draw_as_light
end

local function is_lying(layer)
    return not is_lighting(layer)
       and not is_vertical(dimension(layer))
end

local function is_dead_tree(entity)
    return string.find(entity.name, "dead")
        or string.find(entity.name, "dry")
end

local function get_lying_tree_indexes(prototype)
    local index = {}
    if prototype.variations then
        for i,variation in pairs(prototype.variations) do
            layer_fmap(variation.trunk, function (layer)
                if is_lying(layer) then
                    table.insert(index, i)
                    return true
                end
            end)
        end
    elseif prototype.pictures then
        local i = 1
        for _,sheet in pairs(sprites(prototype.pictures)) do
            local count = sheet.variation_count or 1
            layer_fmap(sheet, function (layer)
                if is_lying(layer) then
                    for x = 0, count - 1 do
                        table.insert(index, i + x)
                    end
                    return true
                end
            end)
            i = i + count
        end
    else error("tree prototype required") end
    return index
end

local function encode(t)
    return table.concat(map(t,tostring), ",")
end

local function pack(tree)
    local name = "lying-tree-indexes-of-" .. tree.name
    return bigpack(name, encode(get_lying_tree_indexes(tree)))
end

for _,tree in pairs(data.raw['tree']) do
    if tree.autoplace and not is_dead_tree(tree) then
        data:extend{pack(tree)}
    end
end

