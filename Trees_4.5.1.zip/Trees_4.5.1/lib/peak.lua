local perlin = require("lib.perlin")


local nan = -0/0
local inf =  1/0


local function id(...) return ... end

local function map(t,f)
    local r = {} for k,v in pairs(t) do r[k] = f(v) end return r
end

local function filter(t,f)
    local r = {} for _,v in pairs(t) do if f(v) then table.insert(r,v) end end return r
end

local function clamp(val,min,max)
    if val < min then val = min end
    if val > max then val = max end
    return val
end

local function contains(t,x)
    for k,v in pairs(t) do if v == x then return true end end return false
end

local function get(t,k,d) return t[k] or d end
local function set(t,k,v) t[k] = v return t end

local function isempty(t) return not next(t) end
local function isstring(s) return type(s) == 'string' end
local function isnumber(num) return num == num and num ~= inf end

local function mmin(a,b) return (a + b - math.abs(a - b)) / 2 end
local function mmax(a,b) return (a + b + math.abs(a - b)) / 2 end

local function Prefix(prefix) return function (key) return prefix .. "_" .. key end end
local function Map(tab) return function (key) return tab[key] or key end end

local function sharp(x, sharpness)
    if sharpness == 0 or x < 0 or x > 1 then return x end
    local h = sharpness / 2
    return (x <     h) and 0
        or (x > 1 - h) and 1
        or (x - h) / (1 - sharpness)
end

local STORE = {} -- memoize
local function memo(f,...)
    return STORE[f] or set(STORE,f,f(...))[f]
end

--------------------------------------------------------------------------------

local   OCTAVES_OF_THE_WORLD = 4 -- just guessed
local ROUGHNESS_OF_THE_WORLD = 2 -- default by perlin

local PROPS = {'temperature','moisture','elevation','distance','aux'}

local PROBMAP = Map{['max']='max_probability', ['random']='random_probability_penalty'}
local DIMMAP = Map{['moisture']='water'}

local PREMAP = {['persistence']='noisePersistence'}
local PRENOISE = Prefix'noise'
local function NOISEMAP(key) return PREMAP[key] or PRENOISE(key) end

local DEFPROB  = {['sharpness']=0, ['max']=1, ['random']=0}
local DEFDIM   = {['optimal']=nan,['range']=0,['max_range']=nan,['top_property_limit']=inf}
local DEFNOISE = {['layer']="", ['scale']=1, ['persistence']=0.5, ['octaves_difference']=0}
local DEFINF   = {['influence']=1, ['min_influence']=-inf, ['max_influence']=inf}

--------------------------------------------------------------------------------

local function get_peaks(name)
    local prototype = game.entity_prototypes[name]
    local spec = prototype and prototype.autoplace_specification
    return spec and spec.peaks or {spec}, spec
end

local function get_restrictions(spec)
    return filter(map(spec.tile_restriction or {}, function (restriction)
        return restriction.first or restriction.second or restriction
    end), isstring)
end

local function get_values(object, keys, name)
    local values = {}
    for key,default in pairs(keys) do
        values[key] = object[name(key)] or default
    end
    return values
end

local function get_dimensions(surface, position)
    local dimension = {['starting_area_weight']=0}
    local props = surface.calculate_tile_properties(PROPS, {position})
    for _,name in pairs(PROPS) do dimension[DIMMAP(name)] = (props[name] or {})[1] end
    return dimension
end

local function get_probability(spec)
    return get_values(spec, DEFPROB, PROBMAP)
end

local function get_peak_dimension(peak, dim)
    return get_values(peak, DEFDIM, Prefix(dim))
end

local function get_peak_noise(peak)
--     return get_values(peak, DEFNOISE, Prefix('noise'))
    return get_values(peak, DEFNOISE, NOISEMAP)
end

local function get_peak_scale(peak)
    return get_values(peak, DEFINF, id)
end

local function is_restricted(surface, position, spec)
    if not spec then return true end
    local allowed = get_restrictions(spec)
    if isempty(allowed) then return false end
    local tile = surface.get_tile(position.x, position.y)
    return not (tile and contains(allowed, tile.name))
end

local function noise_layer_ids()
    local layers = {}
    for _,layer in pairs(game.noise_layer_prototypes) do
        table.insert(layers, {name=layer.name, order=layer.order or ""})
    end
    table.sort(layers, function (a,b) return a.order < b.order end)
    local ids = {}
    for i,layer in ipairs(layers) do ids[layer.name] = i-1 end
    return ids
end

local function get_noise_layer_id(layer)
    return  memo(noise_layer_ids)[layer] or 0
end

local function get_map_seed(surface)
    return surface.map_gen_settings.seed
end

local function get_map_frequency(surface)
    return surface.map_gen_settings.autoplace_controls.trees.frequency
end

--------------------------------------------------------------------------------

local function calculate_distance(d,v)
    return (1 - mmin(1, mmax(0, math.abs(v - d.optimal) - d.range) / (d.max_range - d.range))) * 2 - 1
end

local function generate_peak_noise(peak, position, seed, frequency)
    local noise = get_peak_noise(peak)
    if noise.layer == "" then return 1 end
    perlin:load(get_noise_layer_id(noise.layer))
    local random = perlin:octaves(
        position.x, position.y, seed,
          OCTAVES_OF_THE_WORLD, noise.persistence,
        ROUGHNESS_OF_THE_WORLD * frequency,
        noise.octaves_difference
    ) * noise.scale
    return isnumber(random) and random or 1
end

local function generate_peak_influence(peak, dimension, position, seed, frequency)
    local distance = 1
    local scale = get_peak_scale(peak)
    for dim,value in pairs(dimension) do
        local d = get_peak_dimension(peak,dim)
        if not isnumber(d.optimal) then d.optimal = value end
        local dist = calculate_distance(d, math.min(value,d.top_property_limit))
        if isnumber(dist) then distance = distance + dist end
    end
    return clamp(distance * generate_peak_noise(peak, position, seed, frequency) * scale.influence,
                 scale.min_influence, scale.max_influence)
end

local function calculate_influence(surface, position, peaks)
    local dimension = get_dimensions(surface, position)
    local frequency = get_map_frequency(surface)
    local seed = get_map_seed(surface)
    local influence = 0
    for i,peak in pairs(peaks) do
        influence = influence + generate_peak_influence(peak, dimension, position, seed, frequency)
    end
    return influence
end

local function calculate_sharpness(spec, value)
    local probability = get_probability(spec)
    return sharp(value, probability.sharpness) * probability.max - probability.random
end

local function calculate_probability(surface, position, name)
    local peaks,spec = get_peaks(name)
    if is_restricted(surface, position, spec) then return -inf end
    local influence = calculate_influence(surface, position, peaks)
    return calculate_sharpness(spec, influence)
end

--------------------------------------------------------------------------------

return {
    sharpness   = calculate_sharpness,
    influence   = calculate_influence,
    probability = calculate_probability,
}
