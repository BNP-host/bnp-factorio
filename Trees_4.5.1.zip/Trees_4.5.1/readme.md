
![Treeees v4.0.0](http://www.psycast.de/233bad66d7f03aee4d1a1774c37f782c.gif)
Treeees v4.0.0 with Alien Biomes, 230x speedup

[Treeees v1.x](https://gfycat.com/adoredtestyagama.gif)



# Algorithm
--------------------------------------------------------------------------------
We find pairs of trees within the love radius and add them to a consideration list. With increasing pollution of each tree the love radius is reduced proportionally, so the older trees have less chances to propagate. Accumulated pollution damage is considered within this age calculation, too. The trees will become grey and die faster.
From this consideration list we randomly select trees to be the origin (parents) for the new tree. These selected trees emit one single seed which falls within a randomly selected area around the coordinates of the parent trees. During this stage we add wind speed and direction vectors as bias for the target coordinates calculation.
The new tree type is selected randomly from the origin consideration list at this iteration. We then check this type of tree against peak based configuration of the map for temperature, moisture, elevation, distance and tile restrictions as factors for placement on the chunk with selected coordinates. Further we implement perlin noise generator for influence calculation for placement of new trees on the map. The color of the tree is chosen within boundaries defined by the color variance parameter.
If all of the environmental factors are within boundaries for the selected tree type then this tree is placed on the map. This way we use the world generator of factorio with all user preferences for new tree placement.

# Map Settings
--------------------------------------------------------------------------------

* love radius: maximal distance up to which the trees can be considered as parents (as tiles)
* spawn rate: delay between consecutive algorithm runs (as ticks)
* color variance: tree color variance from the parent (factor between 0 and 1)

We place one single tree on each surface per algorithm run. Since the trees are placed only on the discovered map area (i.e. active chunks) we recommend to set the spawn rate high for early stages of the game. This way we avoid cluttering of the base.

When using this mod we recommend to have game settings set to produce preferably sparse vegetation and let it develop using our mod during the gameplay.


# Documentation
--------------------------------------------------------------------------------
* read the [«FAQ»](https://mods.factorio.com/mod/Trees/faq) and the [«Changelog»](https://mods.factorio.com/mod/Trees/changelog) for more details
* discuss with us on the [«Discussion»](https://mods.factorio.com/mod/Trees/discussion) page


# Compatibility
--------------------------------------------------------------------------------
The tree generation is compatible with the mod [Alien Biomes](https://mods.factorio.com/mod/alien-biomes) and possibly others. We develop and test under [Space Exploration](https://mods.factorio.com/mod/space-exploration). Please report on the mod page discussion if any incompatibilities are discovered.
Works with multiplayer.

# License
--------------------------------------------------------------------------------
The mod ‹Treeees› was made by dodo.the.last and published under The Unlicense.


# Notes
--------------------------------------------------------------------------------
The information on this mod page represents the state of the current release and might be updated without prior notification or public announcement. Please refer to the «Documentation» section of this page for details.




# FAQ
--------------------------------------------------------------------------------

# Found a bug, issue or a missing feature?
--------------------------------------------------------------------------------
Please report bugs or issues to our [mod discussion page](https://mods.factorio.com/mod/Trees/discussion) in accordance with [factorio bug report rules](https://forums.factorio.com/viewtopic.php?f=7&t=3638) or talk with us about the desired features.

# Which major changes happened in the past?
--------------------------------------------------------------------------------
#### Version 4
We add tree lifecycle, which ends when age and pollution damage reached its maximum. If either doesn't then the tree remains in one of the grey stages and falls eventually. After this stage it is decomposed and removed from the map and the cycle can repeat.

We implement perlin noise generator and a sharpness function for influence calculation.

#### Version 3
We check peak based configuration of the map for temperature, moisture, elevation, distance and tile restrictions as factors for placement of the trees. Dead trees aren't placed.

#### Version 2
We consider wind orientation and wind speed as factors for new tree placement. Additionally the love radius is reduced with the tree age. The age calculation considers pollution too.


