
data:extend{
  { -- require corpse flare item
    type = "bool-setting",
    name = "CorpseFlare_requireItems",
    setting_type = "startup",
    default_value = true,
    order = "CF-a[requireItems]",
  },
}
