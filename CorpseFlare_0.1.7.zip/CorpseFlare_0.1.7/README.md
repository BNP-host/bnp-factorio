This mod adds an item you keep in your inventory. When you die with an emergency flare in your inventory, you'll set it off with your dying breath. The advantage of this is that you can find your body faster within the pile of death biters you've caused before the fatal hit.

![Example of the emergency flare](https://raw.githubusercontent.com/LovelySanta/FactorioMod-CorpseFlare/master/graphics/screenshots/CorpseFlare.png)

# Changelog
### Origin
+ Release of the corpe flare as stand alone mod from my [BugZilla](https://mods.factorio.com/mod/BugZilla) mod.
### Latest release
+ See ingame changelog or find it [here on github](https://github.com/LovelySanta/FactorioMod-CorpseFlare/blob/master/changelog.txt).
