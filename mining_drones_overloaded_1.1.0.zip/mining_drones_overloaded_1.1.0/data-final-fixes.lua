-- data.raw["assembling-machine"]["mining-depot"].crafting_speed = settings.startup["mining-drones-overloaded-amount"].value -1
data.raw["item"]["mining-drone"].stack_size = settings.startup["mining-drones-drone-stacksize"].value

for _, resource in pairs(data.raw.resource) do
  -- log("overloading mining drone "..resource.name)
  if data.raw.recipe["mine-"..resource.name] then
    -- log("overloading")
    data.raw.recipe["mine-"..resource.name].overload_multiplier = settings.startup["mining-drones-overloaded-amount"].value
    if data.raw.recipe["mine-"..resource.name].normal then
        data.raw.recipe["mine-"..resource.name].normal.overload_multiplier = settings.startup["mining-drones-overloaded-amount"].value
    end
    if data.raw.recipe["mine-"..resource.name].expensive then
        data.raw.recipe["mine-"..resource.name].expensive.overload_multiplier = settings.startup["mining-drones-overloaded-amount"].value
    end
  end
end