data:extend{
	{
		type = "int-setting",
		name = "mining-drones-overloaded-amount",
		order = "a",
		setting_type = "startup",
		default_value = 200,
        minimum_value = 1,
        maximum_value = 65535
	},
	{
		type = "int-setting",
		name = "mining-drones-drone-stacksize",
		order = "a",
		setting_type = "startup",
		default_value = 20,
        minimum_value = 1,
        maximum_value = 1000
	}
}
