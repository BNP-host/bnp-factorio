local data_util = require("data_util")

-- check to see if there is any way to make space science.
local space_science_name = "space-science-pack"
local rocket_science_name = data_util.mod_prefix .. "rocket-science-pack"

local function find_source_of(item_name)
  -- check for recipes.
  for _, recipe in pairs(data.raw.recipe) do
    if not (string.find(recipe.name, "stack", 1, true) or string.find(recipe.name, "request", 1, true) or string.find(recipe.name, "compress", 1, true)) then
      for _, subname in pairs({"normal", "expensive"}) do
        local table = recipe
        if recipe[subname] then
          table = table[subname]
        end
        if table.result == item_name then
          return true
        end
        if table.results then
          for _, result in pairs(table.results) do
            for _, name in pairs(result) do
              if name == item_name then
                return true
              end
            end
          end
        end
      end
    end
  end

  for _, item in pairs(data.raw.item) do
    if item.rocket_launch_product and (item.rocket_launch_product[1] == item_name or item.rocket_launch_product.name == item_name) then
      return true
    end
  end
end

local space_science_found = find_source_of(space_science_name)
if space_science_found then
  log("Space science source was found. Go to no-conflict mode.")
else
  if settings.startup["se-space-science-pack"].value == "OptimisationUranium" then
    log("No space science source was found. Use alternate recipe:"..settings.startup["se-space-science-pack"].value)
    data:extend({
      {
          type = "recipe",
          name = data_util.mod_prefix .. "space-science-pack",
          enabled = false,
          energy_required = 10,
          ingredients = {
            { "uranium-235", 1 },
            { "processing-unit", 1 },
            { data_util.mod_prefix .. "cryonite-rod", 2 },
          },
          results = {
            {"space-science-pack", 2},
          },
          icon = "__space-exploration-graphics__/graphics/icons/beaker/white.png",
          icon_size = 64,
          main_product = "space-science-pack",
          requester_paste_multiplier = 1,
          subgroup = "science-pack",
      },
    })
    data_util.recipe_require_tech(data_util.mod_prefix .. "space-science-pack", space_science_name)
  elseif settings.startup["se-space-science-pack"].value == "OptimisationFish" then
    log("No space science source was found. Use alternate recipe:"..settings.startup["se-space-science-pack"].value)
    data:extend({
      {
          type = "recipe",
          name = data_util.mod_prefix .. "space-science-pack",
          enabled = false,
          energy_required = 10,
          ingredients = {
            { "raw-fish", 1 },
            { data_util.mod_prefix .. "vitamelange-roast", 1 },
            { data_util.mod_prefix .. "vulcanite", 2 },
            { "coal", 2 },
          },
          results = {
            {"space-science-pack", 2},
          },
          icon = "__space-exploration-graphics__/graphics/icons/beaker/white.png",
          icon_size = 64,
          main_product = "space-science-pack",
          requester_paste_multiplier = 1,
          subgroup = "science-pack",
      },
    })
    data_util.recipe_require_tech(data_util.mod_prefix .. "space-science-pack", space_science_name)
  elseif settings.startup["se-space-science-pack"].value == "Replace" then
    log("No space science source was found. Replace it.")
    for _, technology in pairs(data.raw.technology) do
      local add_prereq = false
      local add_ingredient = false
      if technology.prerequisites then
        for i, prereq in pairs(technology.prerequisites) do
          if prereq == space_science_name then
            add_prereq = true
          end
        end
      end
      for i, ingredient in pairs(technology.unit.ingredients) do
        if ingredient[1] == space_science_name or ingredient.name == space_science_name then
          add_ingredient = true
        end
      end
      data_util.tech_remove_prerequisites(technology.name, {space_science_name})
      data_util.tech_remove_ingredients(technology.name, {space_science_name})
      if add_prereq then
        data_util.tech_add_prerequisites(technology.name, {rocket_science_name})
      end
      if add_ingredient then
        data_util.tech_add_ingredients(technology.name, {rocket_science_name})
      end
    end

    for _, lab in pairs(data.raw.lab) do
      for i, input in pairs(lab.inputs) do
        if input == space_science_name then
          lab.inputs[i] = nil
        end
      end
    end

    data.raw.technology[space_science_name] = nil
    data.raw.item[space_science_name] = nil
    data.raw.tool[space_science_name] = nil

    for _, recipe in pairs (data.raw.recipe) do
      for _, ings in pairs ({recipe.ingredients, recipe.normal and recipe.normal.ingredients or nil, recipe.expensive and recipe.expensive.ingredients or nil}) do
        for _, ing in pairs (ings) do
          if ing[1] == space_science_name then
            ing[1] = rocket_science_name
          elseif ing.name == space_science_name then
            ing.name = rocket_science_name
          end
        end
      end
    end

  else
    log("No space science source was found. Remove it.")
    for _, technology in pairs(data.raw.technology) do
      data_util.tech_remove_prerequisites(technology.name, {space_science_name})
      data_util.tech_remove_ingredients(technology.name, {space_science_name})
    end

    for _, lab in pairs(data.raw.lab) do
      for i, input in pairs(lab.inputs) do
        if input == space_science_name then
          lab.inputs[i] = nil
        end
      end
    end

    data.raw.technology[space_science_name] = nil
    data.raw.item[space_science_name] = nil
    data.raw.tool[space_science_name] = nil

    for _, recipe in pairs (data.raw.recipe) do
      for _, ings in pairs ({recipe.ingredients, recipe.normal and recipe.normal.ingredients or nil, recipe.expensive and recipe.expensive.ingredients or nil}) do
        for i = #ings, 1, -1 do
          local ing = ings[i]
          if ing[1] and ing[1] == space_science_name or ing.name and ing.name == space_science_name then
            table.remove (ings, i)
          end
        end
      end
    end

  end

end
