-- reduce effectivness of matter deconversion
-- otherwise it is too easy to bypass planet resource restrictions.
for _, recipe in pairs(data.raw.recipe) do
  if recipe.subgroup == "matter-deconversion" then
    for _, ingredient in pairs(recipe.ingredients) do
      if ingredient.name == "matter" then
        ingredient.amount = ingredient.amount * 2
        ingredient.catalyst_amount = ingredient.catalyst_amount * 2
      end
    end
  end
end
