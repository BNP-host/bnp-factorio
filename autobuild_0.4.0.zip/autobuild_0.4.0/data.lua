require "custominput"
require "shortcuts"
