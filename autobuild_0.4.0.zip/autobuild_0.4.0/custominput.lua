data:extend{
  {
    type = "custom-input",
    name = "autobuild-toggle-construction",
    key_sequence = "SHIFT + B",
  },
}
