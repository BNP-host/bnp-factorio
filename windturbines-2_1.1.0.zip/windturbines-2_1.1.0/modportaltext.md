I took over the mod and updated it so it runs with factorio version 1.1.0.

Now you can rebuild your windparks :-)  

For dynamic wind changes please use the mod
https://mods.factorio.com/mod/WindSpeedChanging
* the Mk1 runs then with around 6 MW.
* The Mk2 runs then with around 10 MW.
* The Mk3 runs then with around 14 MW.


I am sorry but this does not work with old saves yet.

---

The original mod  
https://mods.factorio.com/mod/windturbines  
by OwnlyMe  
https://mods.factorio.com/user/OwnlyMe

Copyright: CC-BY-SA, except the asset i bought for this mod: https://assetstore.unity.com/packages/3d/props/exterior/wind-turbine-26741

This mod features animated wind turbines that turn towards the wind in 32 steps.
They are pretty huge so you have to leave space between them (that you could fill with solar panels)
The recipes are quite expensive though:

### Mk1 (750 kW):
* 50 Steel Plates
* 40 Plastic Bars
* 120 Copper cables
* 25 Electronic Circuits

### Mk2 (1.5 MW):
* 3 Wind turbines Mk1
* 10 Electric Engine Units
* 25 Advanced Circuits

### Mk3 (3 MW):
* 3 Wind turbines Mk2
* 50 Low density structures
* 25 Processing Units
