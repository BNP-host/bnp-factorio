-- waiting distance
data.raw.roboport.roboport.charge_approach_distance = 5 -- old = 5

-- charging positions
data.raw.roboport.roboport.charging_offsets = {
    { -1.5, -1.5 },
    { -.75, -1.5 },
    {    0, -1.5 },
    {  .75, -1.5 },
    {  1.5, -1.5 },
    {  1.5, -.75 },
    {  1.5,  0   },
    {  1.5,  .75 },
    {  1.5,  1.5 },
    {  .75,  1.5 },
    {    0,  1.5 },
    { -.75,  1.5 },
    { -1.5,  1.5 },
    { -1.5,  .75 },
    { -1.5,  0   },
    { -1.5, -.75 }
}

-- energy transferred to robot per tick
data.raw.roboport.roboport.charging_energy = "20MW" -- old = 1000kW

-- energy properties for the roboport
data.raw.roboport.roboport.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    input_flow_limit = "80MW", -- old = 5MW
    buffer_capacity = "500MJ" -- old = 100MJ
}
