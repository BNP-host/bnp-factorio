-- is the temporary still the default condition ("5s passed")
-- mods (like LTN) use temporary stops with either no conditions, or different conditions, for train routing
-- we don't want the train to shift into manual mode when reaching those temporary stops
-- additionally, this adds a nice feature for vanilla-ish players: if they want a train to continue in automatic
-- mode once it reaches the temporary stop, they can just delete the 5s condition

local function is_default_temporary_stop(schedule_item)
  return schedule_item
    and schedule_item.temporary
    and schedule_item.wait_conditions
    and table_size(schedule_item.wait_conditions) == 1
    and schedule_item.wait_conditions[1]
    and schedule_item.wait_conditions[1].type == 'time'
    and schedule_item.wait_conditions[1].ticks == 300
end

local function should_enter_manual_mode(train)
  if train and train.state == defines.train_state.wait_station and train.schedule and train.schedule.records then
    return is_default_temporary_stop(train.schedule.records[train.schedule.current])
  end
end

-- helper to remove the current stop from the train's schedule, while preserving the correct next stop if the
-- train is switched back into automatic mode.  Here are two example scenarios:
-- Schedule is A,B,C and train is stopped at B. Removing B should make schedule A,C and next stop is C
-- Schedule is A,B,C and train is stopped at C. Removing C should make schedule A,B and next stop is A
-- Schedule is A and train is stopped at A. Removing A should make schedule empty
local function remove_current_stop(train)
  if train and train.schedule and train.schedule.current then
    local schedule = train.schedule
    table.remove(schedule.records, schedule.current)
    local new_length = table_size(schedule.records)
    if new_length > 0 then
      -- if temporary stop was dragged to end of schedule, then next time the train is switched
      -- into automatic mode by the player, the first stop in the schedule is where it should go
      if schedule.current > new_length then
        schedule.current = 1
      end
      train.schedule = schedule
    else
      train.schedule = nil
    end
  end
end

local function on_train_changed_state(event)
  if should_enter_manual_mode(event.train) then
    event.train.manual_mode = true
    remove_current_stop(event.train)
  end
end

script.on_event(defines.events.on_train_changed_state, on_train_changed_state)
