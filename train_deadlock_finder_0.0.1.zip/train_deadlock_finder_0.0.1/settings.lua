

data:extend({
	{
		type = "bool-setting",
		name = "tdf-silent",
		setting_type = "runtime-per-user",
		default_value = false
	},
	{
		type = "bool-setting",
		name = "tdf-allow-unsafe-break",
		setting_type = "runtime-global",
		default_value = false
	}

})
