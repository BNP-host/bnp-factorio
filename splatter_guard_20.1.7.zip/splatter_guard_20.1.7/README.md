# Factorio-Splatter-Guard

Stops you being splattered by trains.

![Splatter Guard Demo](https://media.giphy.com/media/5t5UYRllMIy0jMugxT/giphy.gif)

Preemptive option will constantly check if you are in imminent danger of a train hitting you and teleport you a short distance away to a safe spot before you are hit. The Preemptive option enables the Reactive behaviour as a fallback should the mod fail to detect a danger.

Reactive (Only) option will revert any personal damage done to you by a train and teleport you a short distance away to a safe spot. The train will damage your shields and may be slowed down or damaged itself by the collision.

When a player is teleported they will be held in place for a second to avoid them running back into a train. Takes people a moment to let go of movement keys. A purple smoke effect is used when teleported to highlight the avoided squashing.

Should be fully compatible with all other mods. If another mod makes you invincible you may not jump.

If the Preemptive option is enabled there will be a small UPS cost per player as it has to continuously look for dangers in advance.

Currently if you are not on full health and hit by a train for a lot of damage you may be returned to full health instantly. Shield damage will not be repaired.