local Constants = {}

Constants.ModName = "splatter_guard"
Constants.AssetModName = "__" .. Constants.ModName .. "__"
Constants.LogFileName = Constants.ModName .. "_log_output.txt"

return Constants
