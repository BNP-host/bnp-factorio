if settings.global["train-avoid-mode"].value == "Preemtive" then
    settings.global["train-avoid-mode"].value = "Preemptive"
end

if global.Mod.Settings.trainAvoidMode == "Preemtive" then
    global.Mod.Settings.trainAvoidMode = "Preemptive"
end
